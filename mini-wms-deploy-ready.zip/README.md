# Mini WMS - Deploy Ready
Minimal Warehouse Management System (demo) with FIFO/FEFO logic.
- Inbound/outbound, lots, expiry, picking suggestions.
- In-memory demo (no persistent DB). Suitable for initial testing or demo on Render.
